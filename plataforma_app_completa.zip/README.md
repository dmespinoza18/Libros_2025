# Plataforma Educativa Python

Esta carpeta contiene todos los archivos necesarios para desplegar la app completa en GitHub y Streamlit Cloud.
